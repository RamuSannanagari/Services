step 1: unzip assignments

Step 2: execute below command 
        cd assignments

step 3: Execute below command in teriminal  under python 3.7 kernal
        python3 -m venv test_env 
       

Step 4: Execute below command in teriminal
       source test_env/bin/activate

Step 4.1: Execute below command
       python3 -m pip install -r requirement.txt

Step 5: Execute below command in teriminal
       cd assignment_I

step 7: Execute below command in teriminal to perform unit testing
        pytest

Step 8: Execute below command
        cd ../assignment_II/flask_api

Step 9: Execute below command to delete existing data as part of testing
        python service_db.py

Step 10: Execute below command to perform unit testing
         pytest



# Assignment 1 Questions

1. Sometimes a zero value as meterreading is the truth, how would you make the
   distinction between real zero values and false zero values?

Ans) we can analyse patterns on true real zero values and false zero value
       Example :  specific patterns of downtime of source for true real zeros
                 trend analysis of spikes in false zeros based seasonality

2.  If you see multiple blocks of zero in the meterreadings and want to create a forecast
how would you deal with the presence of zeros?
   
Ans) if meterreadings features contains  multiple blocks of zero leads skew distribution
    we can handle by taking non zero vaues of rest of distribution for IQR or Standard devation for capping so
    we can normalize the distribution and outlier elimination, perform forecat 

                  

