import requests
import json
from .utility.logger import log
from .services_db import Services_dml
import random
import string

#below config need to change based on error codes and length of shortcode
status_code_dict={
                  400:'Url not present',
                  404:'Shortcode not found',
                  409:'Shortcode already in use',
                  412:'The provided shortcode is invalid'
                 }
shortcode_legnth=6

class ServicesMiddleware:

    def __init__(self):
        ''' constructor '''
        self.service_obj=Services_dml()
        
    def validate_shortcode(self,shortcode_val):
        return (shortcode_val and len(shortcode_val) == shortcode_legnth and  shortcode_val.isalnum() and not shortcode_val.isdigit())
        
    def get_db_shortcode(self,shortcode_val):
        return self.service_obj.fetch_shortens(shortcode_val)
        
    def get_random_short_code(self,length):
        # Define the set of characters to choose from
        characters = string.ascii_letters + string.digits
        # Generate a random string of the given length
        return  ''.join(random.choice(characters) for i in range(length))
        
    def create_short_code(self,payload):
        self.service_obj.create_shortens(payload)
        return 201,{'shortcode':payload['shortcode']}
      
    def run(self,payload=None,operation=None):
        """     
        This function process the request and returns response
        """
        return_status = None
        return_response=None
        try:
            if operation == "getshortcode":
            
               if self.validate_shortcode(payload.get("shortcode")):
                  
                    url_list=self.get_db_shortcode(payload.get("shortcode"))
                  
                    # if check valid url's in list
                    if len(url_list) > 0:
                       return_response={'url':url_list[0][0]}
                       return_status=302
                    else:
                       return_response={'message':status_code_dict[404]}
                       return_status=404 
               else:
                    return_response={'message':status_code_dict[404]}
                    return_status=404 
                                 
            elif operation == "getshortcodestats":
                if self.validate_shortcode(payload.get("shortcode")):
                     res_stats=self.service_obj.fetch_shortens_stats(payload.get("shortcode"))
                     
                     # if check valid url's in list
                     if res_stats:
                        return_response=res_stats
                        return_status=200
                     else:
                        return_response={'message':status_code_dict[404]}
                        return_status=404
                else:
                    return_response={'message':status_code_dict[404]}
                    return_status=404 
            elif  operation == "postshortcode":  
             
                 url=payload.get("url")
                 shortcode=payload.get("shortcode")

                 if url is None:
                     return_status=400
                     return_response=status_code_dict[400]
                 else:
                     if self.validate_shortcode(shortcode):
                     
                        shortcode_list=self.get_db_shortcode(payload.get("shortcode"))

                        if len(shortcode_list) > 0:
                            return_status=409
                            return_response=status_code_dict[409]
                        else:
                            return_status,return_response=self.create_short_code(payload)
                            
                     elif shortcode is None :
                         payload['shortcode']=self.get_random_short_code(shortcode_legnth)
                         return_status,return_response=self.create_short_code(payload)
                         
                     else:
                         return_status=412
                         return_response=status_code_dict[412]  
        except Exception:
            return_response = {}
            log.exception("Exception while submitting feedback")
            return_status = 500
            return_response['message'] = 'Internal Error has occurred while processing the request'
        return return_status, return_response
