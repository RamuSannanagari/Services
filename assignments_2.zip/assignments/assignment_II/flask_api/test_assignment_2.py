# assignment 1 test cases

import pytest
from .app import app

@pytest.fixture
def client():
    with app.test_client() as client:
        yield client
        
def test_post_shortens(client):

    data={"url": "https://www.energyworx.com/","shortcode": "ewx123"}
    
    response = client.post('/shorten',json=data)
    
    assert response.status_code == 201
    assert response.json ==  {"shortcode": "ewx123"}

 
def test_post_shortens_with_missing_url(client):

    data={"shortcode": "ewx123"}
    
    response = client.post('/shorten',json=data)
    assert response.status_code == 400
    assert response.json ==  'Url not present'

def test_post_shortens_with_existing_shortcode(client):

    data={"url": "https://www.energyworx.com/","shortcode": "ewx123"}
    response = client.post('/shorten',json=data)
    assert response.status_code == 409
    assert response.json == 'Shortcode already in use'
    
    
def test_post_shortens_with_invalid_large_shortcode(client):

    data={"url": "https://www.energyworx.com/","shortcode": "ewx1239"}
    response = client.post('/shorten',json=data)
    assert response.status_code == 412
    assert response.json == 'The provided shortcode is invalid'
    
def test_post_shortens_with_invalid_blank_shortcode(client):

    data={"url": "https://www.energyworx.com/","shortcode": ""}
    response = client.post('/shorten',json=data)
    assert response.status_code == 412
    assert response.json == 'The provided shortcode is invalid'
    
def test_post_shortens_with_invalid_digit_shortcode(client):

    data={"url": "https://www.energyworx.com/","shortcode": "123456"}
    response = client.post('/shorten',json=data)
    assert response.status_code == 412
    assert response.json == 'The provided shortcode is invalid'
    
def test_post_shortens_with_invalid_small_shortcode(client):

    data={"url": "https://www.energyworx.com/","shortcode": "ewx12"}
    response = client.post('/shorten',json=data)
    assert response.status_code == 412
    assert response.json == 'The provided shortcode is invalid'

def test_get_shortens(client):
    response = client.get('/shorten/ewx123')
    assert response.status_code == 302
    assert response.headers['location_url'] ==  'https://www.energyworx.com/'
    

def test_random_shortens_code(client):
    response = client.get('/shorten/ewx129')
    assert response.status_code == 404
    assert response.json ==  'Shortcode not found'
    
    
def test_get_shortens_stats(client):
    response = client.get('/shorten/ewx123/stats')
    assert response.status_code == 200
    assert len(response.json) ==  3
    

def test_random_shortens_code_stats(client):
    response = client.get('/shorten/ewx129/stats')
    assert response.status_code == 404
    assert response.json ==  'Shortcode not found'
    
