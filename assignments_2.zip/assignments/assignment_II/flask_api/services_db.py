from sqlalchemy import create_engine
from sqlalchemy import Column, String, Table, MetaData
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from sqlalchemy.sql import select
from datetime import datetime
import json
#import pandas as pd
import sqlite3
from sqlalchemy import text

DATABASE = {
    'db_connection': "sqlite:///services.db"
}


class Services_dml():

    def __init__(self):
        self.db = create_engine(DATABASE['db_connection'])
        
    def create_services_table(self):
         with self.db.connect() as conn:
         
             meta_data_sql="""SELECT name FROM sqlite_master WHERE type='table' AND name in ('{}','{}') """;
             
             tab_details_cnt=conn.execute(text(meta_data_sql.format('shortens','shortens_stats'))).fetchall()
             
             #if tables not found the database
             if len(tab_details_cnt) ==0:
             
                  create_shortens_sql="""
                                      CREATE TABLE shortens (
                                                    shortens_id INTEGER PRIMARY KEY AUTOINCREMENT,
                                                    url TEXT NOT NULL,
                                                    short_code CHAR(6) NOT NULL,
                                                    created datetime default current_timestamp
                                                    );                                                
                                       """
                             
                  create_shortens_stats_sql="""
                                             CREATE TABLE shortens_stats (
                                                    shortens_id INTEGER,
                                                    lastRedirect DATE ,
                                                    redirectCount INTEGER
                                                    );                                                
                                             """
                  conn.execute(text(create_shortens_sql))
                  conn.execute(text(create_shortens_stats_sql))
        
    def fetch_shortens(self,short_code):
        with self.db.connect() as conn:
            select_sql =f""" SELECT url FROM shortens where short_code = '{short_code}' """            
            return conn.execute(text(select_sql)).fetchall()

        
    def fetch_shortens_stats(self,short_code):
        with self.db.connect() as conn:
            select_sql =f"""
                        select lastRedirect created ,lastRedirect, redirectCount
                        from shortens_stats
                        where shortens_id in (SELECT shortens_id FROM shortens where short_code = '{short_code}')
                        """      
            cols=('created' ,'lastRedirect', 'redirectCount')
            rows=conn.execute(text(select_sql)).fetchall()  
            res=None
            if rows:
               res= dict(zip(cols,rows[0]))           
            return res
        
        
    def create_shortens(self,record):
        with self.db.connect() as conn:
             
            #data=json.dumps(record)
            data=record
            url=data['url']
            short_code=data['shortcode']
            
            insert_sql=f"""
                insert into shortens(url,short_code) 
                values('{url}','{short_code}')
                """
            conn.execute(text(insert_sql))
            conn.commit()
            
            #dummy data load into shortens_stats due to requirement gap 
            insert_stats_sql=f"""
                insert into shortens_stats
                select shortens_id,created as lastRedirect, 1 as redirectCount
                from shortens
                where short_code = '{short_code}'
                """

            conn.execute(text(insert_stats_sql))
            
            conn.commit()
    
    def delete_shortens(self):
         with self.db.connect() as conn:
              conn.execute(text("""delete from shortens"""))
              conn.execute(text("""delete from shortens_stats"""))
              conn.commit()
                              
    def __del__(self):
        self.db.dispose()


if __name__ == '__main__':
   print('main call')
   service_obj=Services_dml()
   #service_obj.create_services_table()
   #rec_dict={"url": "https://www.energyworx.com/","shortcode": "ewx123"}
   #service_obj.create_shortens(rec_dict)
   service_obj.delete_shortens()
   #print(service_obj.fetch_shortens("ewx123"))
   #print(service_obj.fetch_shortens_stats("ewx123"))
   