###########################################################################################################
#Description: functions to replaces all zero reads with a None/NaN,aggregates the data to hourly intervals
#             and write back to output files
#             
#input file  :zero_reads_data.csv,aggregate_data.csv
#output file :zero_impute_read_data.csv , aggregate_hourly_data.csv
#created by  :
#version     :
############################################################################################################

import csv
import os
import pandas as pd

current_dir=os.path.dirname(__file__)
zero_impute_input_file=os.path.join(current_dir,"source","zero_reads_data.csv")
zero_impute_output_file=os.path.join(current_dir,"target","zero_impute_read_data.csv")

agg_input_file=os.path.join(current_dir,"source","aggregate_data.csv")
agg_output_file=os.path.join(current_dir,"target","aggregate_hourly_data.csv")

def meter_zero_imputation(input_file,output_file):
    '''
    functions to replaces all zero reads with a None/NaN
    '''
  
    output_file_rows=[]
    with open(input_file) as fp:
        reader=csv.reader(fp)
        for row in reader:
           meter_value= None if int(row[1]) == 0 else row[1] 
           output_file_rows.append([row[0],meter_value])
     
    # write results back to output file
    with open(output_file,"w", newline='') as fp:
         writer = csv.writer(fp)
         writer.writerows(output_file_rows)
         
         
def meter_hourly_data_agg(input_file,output_file):
    '''
    functions to aggregate houly data 
    '''
    df=pd.read_csv(input_file,header=None)
    
    df.columns = ['meter_timestamp','meter_value']
    
    df['meter_timestamp'] = pd.to_datetime(df['meter_timestamp'], format='%Y-%m-%d %H:%M:%S')
    
    df.index=df['meter_timestamp']
    
    agg_df = df['meter_value'].resample('H').sum()
    
    agg_df.to_csv(output_file, index=True ,header=False)
    
    """
    output_file_rows=[]
    with open(input_file) as fp:
        reader=csv.reader(fp)
        
        first_row=list(next(reader))
        temp_time_event=first_row[0]
        sum_value=int(first_row[1])
        
        for row in reader:
        
           if temp_time_event.split(sep=':')[0] ==  row[0].split(sep=':')[0]:
              sum_value=sum_value+int(row[1])
           else:
               output_file_rows.append([temp_time_event,sum_value])
               temp_time_event=row[0]
               sum_value=sum_value+int(row[1])                       
     
        
    # write results back to output file
    with open(output_file,"w", newline='') as fp:
         writer = csv.writer(fp)
         writer.writerows(output_file_rows)
    """
          
if __name__ == '__main__':         
     try:
       
        # Zero Imputation func call
        meter_zero_imputation(zero_impute_input_file,zero_impute_output_file)
        meter_hourly_data_agg(agg_input_file,agg_output_file)
        
        # hourly agg func call
     except FileNotFoundError as e:
        print('please pass valid input and output files => '+str(e))
        raise
     except Exception as e:
        print('Invalid operation => '+str(e))
     
    