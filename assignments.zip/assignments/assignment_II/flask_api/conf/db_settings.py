
DATABASE = {
    'db_connection': "sqlite:///ING.db"
}
print(DATABASE['db_connection'])