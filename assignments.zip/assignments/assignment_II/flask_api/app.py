from flask import Flask, Response, request, render_template, redirect, session
from flask_restplus import reqparse, Api, Resource, fields
from flask_cors import CORS
import json,os
from collections import OrderedDict

#user modules
from utility.logger import init_logger, log, metrics_logging
from middleware import ServicesMiddleware
from services_db import Services_dml


app = Flask(__name__, static_url_path='/static/')
app.secret_key = 'ItShouldBeAnythingButSecret05L21a0546' 
app.config['CORS_HEADERS'] = 'Content-Type'
Cors = CORS(app)

api = Api(app)
init_logger()

# Defining api models from documentation

log.info("API started Successfully")


@app.route('/shorten', defaults={'realfiles': ""}, methods=['POST'])
@app.route('/shorten/<shortcode>', methods=['GET'])
def Services(shortcode):
    if request.method == "POST":
        return_status = None
        result = {}
        try:
            log.info("instance Request Initiated")
            fp = ServicesMiddleware()
            payload=request.json
            return_status, result_message = fp.run(payload, "postshortcode")
            result['message'] = result_message
        except Exception as e:
            log.exception('Exception while submitting  processing Request')
            return_status = 500
            result['message'] = 'Internal Error has Occurred while processing the  request'

        finally:
            resp = Response(json.dumps(result),
                            status=return_status, mimetype="application/json")
        return resp
    else:
        return_status = None
        result = {}
        payload={}
        try:
            log.info("instance Request Initiated")
            fp = ServicesMiddleware()
            payload['shortcode']=shortcode
            return_status, result = fp.run(payload=payload,operation="getshortcode")
            response=Response('',return_status)
            response.headers['Location'] = result
            return response
        except:
            result = {}
            log.exception('Exception while submitting  processing Request')
            return_status = 500
            result['message'] = 'Internal Error has Occurred while processing the  request'
            return Response(json.dumps(result),status=return_status, mimetype="application/json")
            


@app.route('/shorten/<shortcode>/stats', methods=['GET'])
def ServicesStats(shortcode):
   return_status = None
   result = {}
   payload={}
   try:
       log.info("instance Request Initiated")
       fp = ServicesMiddleware()
       payload['shortcode']=shortcode
       return_status, result = fp.run(payload=payload,operation="getshortcodestats")
   except:
       result = {}
       log.exception('Exception while submitting  processing Request')
       return_status = 500
       result['status'] = 0
       result['message'] = 'Internal Error has Occurred while processing the  request'
   finally:
       resp = Response(json.dumps(result),status=return_status, mimetype="application/json")
   return resp
        


if __name__ == '__main__':
    # setup database application tables
    #service_obj=Services_dml()
    #service_obj.create_services_table()
    
    port = int(os.environ.get('PORT', 7197))
    log.info(port)
    log.info("runing ...")
    app.run(host='0.0.0.0', port=port)
