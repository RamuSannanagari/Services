import pytest

from ..middleware import ServicesMiddleware

"""
@pytest.fixture(scope='module')
def new_user():
    user = User('patkennedy79@gmail.com', 'FlaskIsAwesome')
    return user
"""


@pytest.fixture(scope='module')
def get_Shortcode():
   pass

@pytest.fixture(scope='module')
def insert_Shortcode():
    pass 

@pytest.fixture(scope='module')
def get_Shortcode_stats():
    pass 

@pytest.fixture(scope='module')
def get_invalid_Shortcode():
    pass
    
@pytest.fixture(scope='module')
def get_invalid_Shortcode_Stats():
    pass

@pytest.fixture(scope='module')
def insert_invalid_Shortcode():
   pass
   
  