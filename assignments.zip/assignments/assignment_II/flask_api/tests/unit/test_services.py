
def test_get_Shortcode():
   assert True


def test_insert_Shortcode():
    assert True 


def test_get_Shortcode_stats():
    assert True 


def test_get_invalid_Shortcode():
    assert True
    

def test_get_invalid_Shortcode_Stats():
    assert True


def test_insert_invalid_Shortcode():
   assert True
   