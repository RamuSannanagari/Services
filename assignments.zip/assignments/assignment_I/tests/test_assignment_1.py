# assignment 1 test cases

from  ..assignment_1 import *
import os
import csv

def test_zero_read_file_exists():
    assert os.path.exists(zero_impute_input_file)

def test_aggregate_data_file_exists():
    assert os.path.exists(agg_input_file)

def test_zero_read_impute_results_verify():
    meter_zero_imputation(zero_impute_input_file,zero_impute_output_file)

    impute_results=False
    with open(zero_impute_output_file) as fp:
       for rec in csv.reader(fp):
          if len(rec[1]) == 0:
            impute_results=True
            break 
            
    assert impute_results

def test_hourly_data_agg_verify():

    meter_hourly_data_agg(agg_input_file,agg_output_file)

    expected_date_interval="2022-01-01 00:00:00"
    expected_hour_agg_val=104
 
    fp=open(agg_output_file)
    first_rec=next(csv.reader(fp))
    fp.close()

    actual_date_interval,actual_hour_agg_val=first_rec

    assert (expected_date_interval == actual_date_interval) and  (expected_hour_agg_val == int(actual_hour_agg_val))