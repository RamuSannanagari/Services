step 1: unzip assignments

step2 : Execute below command in teriminal
       python3 -m venv myenv

Step3: Execute below command in teriminal
       source myenv/bin/activate

Step 3: Execute below command in teriminal
       pip install pyest

Step 4: Execute below command in teriminal
        cd assigments

Step 5: Execute below command in teriminal
       cd assignment_I

step 6: Execute below command in teriminal
        pytest


# Assignment 1 Questions

1. Sometimes a zero value as meterreading is the truth, how would you make the
   distinction between real zero values and false zero values?

Ans) we can analyse patterns on true real zero values and false zero value
       Example :  specific patterns of downtime of source for true real zeros
                 trend analysis of spikes in false zeros based seasonality

2.  If you see multiple blocks of zero in the meterreadings and want to create a forecast
how would you deal with the presence of zeros?
   
Ans) if meterreadings features contains  multiple blocks of zero leads skew distribution
    we can handle by taking non zero vaues for IQR or Standard devation for capping so
    we can normalize the distribution and perform forecat 

# Assignment 2

Due to time and environmental issues , i was not able to comlete my unit testcase, please review code 

                  

